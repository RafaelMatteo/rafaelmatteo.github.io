### Graphic User Interface and Event handling.

from tkinter import Text, Button, END
from logic.calculator_logic import evaluate_expression

class Calculator():
    ### Constants definition
    WINDOW_TITLE = "Basic Calculator - V:1.0"
    SCREEN_BACKGROUND = "#00FF00" ### Green color
    SCREEN_FOREGROUND = "#000000" ### Black color
    
    def __init__(self, window):
        ### Create the main window with descriptive title.
        self.window = window
        self.window.title(self.WINDOW_TITLE)
        
        self.create_screen()
        
        ### Initialize the operation displayed on the screen as an empty string.
        self.operation = ""
        
        self.create_all_buttons()
        
        return


    #### Create the Calculator screen   
    def create_screen(self):
        ### Configures the Calculator screen
        self.screen = Text(
            self.window, 
            state="disabled", 
            width=45, 
            height=3, 
            background="#00ff00", ### Green color.
            foreground="#000000", ### Black color.
            font=("Arial", 15))
        
        ### Locate the screen in the window.
        self.screen.grid(
            row=0, 
            column=0, 
            columnspan=4, 
            padx=5, 
            pady=5)     
        
        return
    
    
    #### Create and place buttons.
    def create_all_buttons(self):
        buttons = [
            self.create_button(7), self.create_button(8), self.create_button(9), self.create_button("C", write=False),
            self.create_button(4), self.create_button(5), self.create_button(6), self.create_button(u"\u00F7"),
            self.create_button(1), self.create_button(2), self.create_button(3), self.create_button("*"),
            self.create_button("."), self.create_button(0), self.create_button("+"), self.create_button("-"),
            self.create_button("=", write=False, width=20, height=2)
        ]

        counter = 0
        for row in range(1, 5):
            for column in range(4):
                buttons[counter].grid(row=row, column=column)
                counter += 1
        
        ### Place the last button at the end (equal button "=").
        buttons[-1].grid(row=5, column=0, columnspan=4)
        
        return
    
    
    #### Create a button with the value to display.
    def create_button(self, value, write=True, width=9, height=1):
        
        return Button(
            self.window, 
            text=value, 
            width=width, 
            height=height, 
            font=("Arial", 15, 'bold'), 
            command=lambda: self.click(value, write))
        
        
    #### When is clicked a button, then control the event triggered .
    def click(self, text, write):
        ### If 'write' parameter is True then, 'text' parameter is showing in screen. Not if it is False.
        if not write:
            ### Only evaluate if there is an operation or user clicked '=' button.
            if text == "=" and self.operation:
                ### Replace the unicode value for division with the Python division operator '/'.
                result = evaluate_expression(self.operation)
                self.operation = ""
                self.clear_screen()
                self.show_in_screen(result)
            ### If the clear button "C" was clicked, then clear the screen.
            elif text == "C":
                self.operation = ""
                self.clear_screen()
        ### Show text in the screen.
        else:
            self.operation += str(text)
            self.show_in_screen(text)
        
        return


    #### Clear the contents of the screen.
    def clear_screen(self):
        self.screen.configure(state = "normal") ### "normal" acept changes.
        self.screen.delete("1.0", END) ### Clear all screen text.
        self.screen.configure(state = "disabled") ### "disabled" not acept changes.
        
        return


    #### Shows the operations content and the results on the screen.
    def show_in_screen(self, value):
        self.screen.configure(state = "normal") ### "normal" acept changes.
        self.screen.insert(END, value) ### Insert the value clicked et the end.
        self.screen.configure(state = "disabled") ### "disabled" not acept changes.
        
        return
