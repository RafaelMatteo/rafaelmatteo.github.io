### Initializes and runs the application.
from tkinter import Tk
from gui.calculator_gui import Calculator

def main():
    main_window = Tk()
    calculator = Calculator(main_window)
    main_window.mainloop() ### Wait for events.

if __name__ == "__main__":
    main()
