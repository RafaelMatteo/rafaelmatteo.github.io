import re


def evaluate_expression(expression):

    # Reemplaza el símbolo de división Unicode por el operador de Python
    expression = re.sub(u"\u00F7", "/", expression)

    # Evalúa la expresión y devuelve el resultado   
    return eval(expression)
