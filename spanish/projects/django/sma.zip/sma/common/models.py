# common/models.py

from django.db import models

# Create your models here.
class Person(models.Model):
    id_number = models.CharField(max_length=25, unique=True)
    name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    birth_date = models.DateField()
    sex = models.CharField(max_length=10, blank=True)
    nationality = models.CharField(max_length=150, blank=True)
    address = models.CharField(max_length=150, blank=True)
    city = models.CharField(max_length=150, blank=True)
    phone = models.CharField(max_length=25, unique=True, blank=True, null=True)
    email = models.EmailField(unique=True, blank=True, null=True)
    
    class Meta:
        abstract = True
        
    def __str__(self):
        return f'{self.name} {self.last_name}'