# groups/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from groups.forms import GroupCreationForm, GroupChangeForm
from groups.models import Group


@login_required
def groupList(request):
    groups = Group.objects.order_by('name')  # Query all groups and order them by name
    total_groups = Group.objects.count()  # Count total number of groups
    return render(request, 'groups/groupList.html', {'groups': groups, 'total_groups': total_groups})
    # Render the template with groups and total_groups count


@login_required
def groupDetails(request, id):
    group = get_object_or_404(Group, pk=id)  # Get the group instance by its primary key
    subjects = group.subjects.all()  # Retrieve all subjects related to the group
    students = group.students.order_by('id_number')  # Order students by their identification number
    
    return render(request, 'groups/groupDetails.html', {'group': group, 'subjects': subjects, 'students': students})
    # Render the template with group details, subjects, and students


@login_required
def groupCreation(request):
    if request.method == 'POST':
       form = GroupCreationForm(request.POST)  # Bind POST data to GroupCreationForm
       if form.is_valid():
            form.save()  # Save the form data to create a new Group instance
            return redirect('groupList')  # Redirect to group list page after successful creation
    else:
        form = GroupCreationForm()  # Create a new instance of GroupCreationForm for GET requests

    return render(request, 'groups/groupCreation.html', {'form': form})
    # Render the template with the form for creating a new group


@login_required
def groupUpdate(request, id):
    group = get_object_or_404(Group, pk=id)  # Get the group instance by its primary key
    if request.method == 'POST':
        form = GroupChangeForm(request.POST, instance=group)  # Bind POST data to GroupChangeForm with instance
        if form.is_valid():
            form.save()  # Save the form data to update the existing Group instance
            return redirect('groupList')  # Redirect to group list page after successful update
    else:
        form = GroupChangeForm(instance=group)  # Create a form instance for the existing group instance

    return render(request, 'groups/groupUpdate.html', {'form': form})
    # Render the template with the form for updating an existing group


@login_required
def groupDelete(request, id):
    group = get_object_or_404(Group, pk=id)  # Get the group instance by its primary key
    if group:
        group.delete()  # Delete the group instance
    return redirect('groupList')  # Redirect to group list page after deletion
