# groups/urls.py

from django.urls import path
from groups.views import groupCreation, groupDelete, groupDetails, groupList, groupUpdate 


urlpatterns = [
    path('groupList/', groupList, name='groupList'),
    path('groupCreation/', groupCreation, name='groupCreation'),
    path('groupDetails/<int:id>', groupDetails, name='groupDetails'),
    path('groupUpdate/<int:id>', groupUpdate, name='groupUpdate'),
    path('groupDelete/<int:id>', groupDelete, name='groupDelete'),
]