# groups/admin.py

from django.contrib import admin
from groups.models import Group


admin.site.register(Group)  # Register Group model to appear in Django admin interface

