# groups/forms.py

from django.forms import ModelForm
from groups.models import Group


# Form for creating new Group instances
class GroupCreationForm(ModelForm):

    class Meta:
        model = Group  # Model for form generation
        fields = '__all__'  # Fields from Group model in the form


# Form for updating existing Group instances
class GroupChangeForm(ModelForm):

    class Meta:
        model = Group  # Model for form generation
        fields = '__all__'  # Fields from Group model in the form
