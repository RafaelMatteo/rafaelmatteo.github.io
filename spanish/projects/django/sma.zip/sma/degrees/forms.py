# degrees/forms.py

from django.forms import ModelForm
from degrees.models import Degree


# Form for creating a new Degree instance
class DegreeCreationForm(ModelForm):

    class Meta:
        model = Degree  # Model for which the form is created
        fields = '__all__'  # Fields from Degree model in the form

# Form for updating an existing Degree instance
class DegreeChangeForm(ModelForm):

    class Meta:
        model = Degree  # Model for which the form is created
        fields = '__all__'  # Fields from Degree model in the form

