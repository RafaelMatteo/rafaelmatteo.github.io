# degrees/admin.py


from django.contrib import admin
from degrees.models import Degree

admin.site.register(Degree)  # Register the Degree model with Django's admin interface
