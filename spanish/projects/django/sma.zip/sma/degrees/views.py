# degrees/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from degrees.forms import DegreeCreationForm, DegreeChangeForm
from degrees.models import Degree


@login_required
def degreeList(request):
    degrees = Degree.objects.order_by('name')  # Query all degrees ordered by name
    total_degrees = Degree.objects.count()  # Count total number of degrees
    return render(request, 'degrees/degreeList.html', {'degrees': degrees, 'total_degrees': total_degrees})  # Render degree list template with degrees and total_degrees context


@login_required
def degreeDetails(request, id):
    degree = get_object_or_404(Degree, pk=id)  # Get degree by id or return 404 error
    return render(request, 'degrees/degreeDetails.html', {'degree': degree})  # Render degree details template with degree context


@login_required
def degreeCreation(request):
    if request.method == 'POST':
        form = DegreeCreationForm(request.POST)  # Create form instance with POST data
        if form.is_valid():
            form.save()  # Save new degree if form is valid
            return redirect('degreeList')  # Redirect to 'degreeList' URL after successful creation
    else:
        form = DegreeCreationForm()  # Create empty form instance

    return render(request, 'degrees/degreeCreation.html', {'form': form})  # Render degree creation template with form context


@login_required
def degreeUpdate(request, id):
    degree = get_object_or_404(Degree, pk=id)  # Get degree by id or return 404 error
    if request.method == 'POST':
        form = DegreeChangeForm(request.POST, instance=degree)  # Create form instance with POST data and degree instance
        if form.is_valid():
            form.save()  # Save degree updates if form is valid
            return redirect('degreeList')  # Redirect to 'degreeList' URL after successful update
    else:
        form = DegreeChangeForm(instance=degree)  # Create form instance with degree instance

    return render(request, 'degrees/degreeUpdate.html', {'form': form})  # Render degree update template with form context


@login_required
def degreeDelete(request, id):
    degree = get_object_or_404(Degree, pk=id)  # Get degree by id or return 404 error
    if degree:
        degree.delete()  # Delete degree if degree exists
    return redirect('degreeList')  # Redirect to 'degreeList' URL after deletion