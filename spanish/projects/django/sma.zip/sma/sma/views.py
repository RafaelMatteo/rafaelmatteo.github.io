# sma/views.py

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from datetime import datetime
from accounts.models import CustomUser
from degrees.models import Degree
from subjects.models import Subject
from students.models import Student
from teachers.models import Teacher
from references.models import Reference
from groups.models import Group


@login_required
def home(request):
    # Retrieve counts for various model instances
    total_users = CustomUser.objects.count()
    total_students = Student.objects.count()
    total_teachers = Teacher.objects.count()
    total_references = Reference.objects.count()
    total_degrees = Degree.objects.count()
    total_subjects = Subject.objects.count()
    total_groups = Group.objects.count()
    
    # Get current date in a formatted string
    date = datetime.now().strftime('%A, %d %B %Y')
    
    # Render home.html template with context data
    return render(request, 'home.html', {
                                        'total_users': total_users,
                                        'total_students': total_students,
                                        'total_teachers': total_teachers,
                                        'total_references': total_references,
                                        'total_degrees': total_degrees,
                                        'total_subjects': total_subjects,
                                        'total_groups': total_groups,
                                        'date': date
    })
