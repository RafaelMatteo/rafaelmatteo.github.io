# accounts/admin.py

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .forms import CustomUserCreationForm, CustomUserChangeForm  # custom user forms
from .models import CustomUser  # custom user model

## Custom admin configuration for the CustomUser model
class CustomUserAdmin(UserAdmin):
    add_form = CustomUserCreationForm  # Form for adding new CustomUser
    form = CustomUserChangeForm  # Form for editing existing CustomUser
    model = CustomUser  # The model managed by this admin
    list_display = ["email", "username"]  # Fields to display in admin list view

# Register CustomUser model with its admin configuration
admin.site.register(CustomUser, CustomUserAdmin)
