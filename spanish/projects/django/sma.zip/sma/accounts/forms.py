# accounts/forms.py

from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.forms import EmailInput

from .models import CustomUser 

# Form for creating a new CustomUser
class CustomUserCreationForm(UserCreationForm):

    class Meta:
        model = CustomUser  # Model for which the form is created
        fields = '__all__'  # Includes all fields from the model
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})  # Sets the email field to use email input type
        }

# Form for updating an existing CustomUser
class CustomUserChangeForm(UserChangeForm):

    class Meta:
        model = CustomUser  # Model for which the form is created
        fields = '__all__'  # Includes all fields from the model
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})  # Sets the email field to use email input type
        }
