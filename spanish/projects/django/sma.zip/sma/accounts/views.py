# accounts/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from accounts.models import CustomUser
from accounts.forms import CustomUserChangeForm, CustomUserCreationForm


@login_required
def userList(request):
    users = CustomUser.objects.order_by('id_number')  # Query all users ordered by id_number
    total_users = CustomUser.objects.count()  # Count total number of users
    return render(request, 'users/userList.html', {'users': users, 'total_users': total_users})  # Render user list template with users and total_users context


@login_required
def userDetails(request, id):
    user = get_object_or_404(CustomUser, pk=id)  # Get user by id or return 404 error
    return render(request, 'users/userDetails.html', {'user': user})  # Render user details template with user context


@login_required
def userCreation(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)  # Create form instance with POST data
        if form.is_valid():
            form.save()  # Save new user if form is valid
            return redirect('home')  # Redirect to 'home' URL after successful creation
    else:
        form = CustomUserCreationForm()  # Create empty form instance

    return render(request, 'users/userCreation.html', {'form': form})  # Render user creation template with form context


@login_required
def userUpdate(request, id):
    user = get_object_or_404(CustomUser, pk=id)  # Get user by id or return 404 error
    if request.method == 'POST':
        form = CustomUserChangeForm(request.POST, instance=user)  # Create form instance with POST data and user instance
        if form.is_valid():
            form.save()  # Save user updates if form is valid
            return redirect('userList')  # Redirect to 'userList' URL after successful update
    else:
        form = CustomUserChangeForm(instance=user)  # Create form instance with user instance

    return render(request, 'users/userUpdate.html', {'form': form})  # Render user update template with form context


@login_required
def userDelete(request, id):
    user = get_object_or_404(CustomUser, pk=id)  # Get user by id or return 404 error
    if user:
        user.delete()  # Delete user if user exists
    return redirect('userList')  # Redirect to 'userList' URL after deletion
