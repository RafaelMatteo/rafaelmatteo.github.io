# subjects/forms.py

from django.forms import ModelForm
from subjects.models import Subject


class SubjectCreationForm(ModelForm):
    
    class Meta:
        model = Subject
        fields = '__all__' # Include all fields from the Subject model for creation
        
        
class SubjectChangeForm(ModelForm):

    class Meta:
        model = Subject
        fields = '__all__' # Include all fields from the Subject model for updating
