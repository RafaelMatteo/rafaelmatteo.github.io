# subjects/admin.py

from django.contrib import admin
from subjects.models import Subject

# Register the Subject model for administration
admin.site.register(Subject)