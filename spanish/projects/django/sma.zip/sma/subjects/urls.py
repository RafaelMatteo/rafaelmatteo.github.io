# students/urls.py

from django.urls import path
from subjects.views import assignSubjectToGroups, subjectCreation, subjectDelete, subjectDetails, subjectList, subjectUpdate


urlpatterns = [
    path('subjectList', subjectList, name='subjectList'),
    path('subjectCreation', subjectCreation, name='subjectCreation'),
    path('subjectDetails/<int:id>', subjectDetails, name='subjectDetails'),
    path('subjectUpdate/<int:id>', subjectUpdate, name='subjectUpdate'),
    path('subjectDelete/<int:id>', subjectDelete, name='subjectDelete'),
    path('assignSubjects', assignSubjectToGroups, name='assignSubjects'),
]