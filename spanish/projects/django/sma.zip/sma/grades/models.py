# grades/models.py

from django.db import models
from groups.models import Group
from subjects.models import Subject
from students.models import Student


class MonthlyGrade(models.Model):
    group = models.ForeignKey(Group, related_name='month_ratings', on_delete=models.CASCADE)
    student = models.ForeignKey(Student, related_name='month_ratings', on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, related_name='month_ratings', on_delete=models.CASCADE)
    month = models.CharField(max_length=15)
    month_grade = models.CharField(max_length=20)
 
    def __str__(self):
        return f'{self.student} - {self.group} - {self.month} - {self.subject.name}: {self.month_grade}'
