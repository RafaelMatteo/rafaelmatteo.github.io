# ratings/views.py


from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.shortcuts import render
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from sma.constants import SCHOOL_YEAR, MONTH_GRADES
from groups.models import Group
from grades.models import MonthlyGrade
from subjects.models import Subject
from students.models import Student


@login_required
def monthlyGradeAssign(request):
    subjects = Subject.objects.order_by('name')  # Query all subjects ordered by name
    groups = Group.objects.order_by('name')  # Query all groups ordered by name
    students = Student.objects.order_by('id_number')  # Query all students ordered by id_number
    month = SCHOOL_YEAR
    month_grades = MONTH_GRADES

    return render(request, 'grades/monthlyGradeAssign.html', {'groups': groups,
                                                               'students': students,
                                                               'subjects': subjects,
                                                               'months': month,
                                                               'month_grades': month_grades,
                                                                })


@login_required
def monthlyGradeUpdate(request):
    subjects = Subject.objects.order_by('name')  # Query all subjects ordered by name
    groups = Group.objects.order_by('name')  # Query all groups ordered by name
    students = Student.objects.order_by('id_number')  # Query all students ordered by id_number
    monthlyGrades = MonthlyGrade.objects.order_by('group')  # Query all monthly grades ordered by group
    month = SCHOOL_YEAR
    month_grades = MONTH_GRADES

    return render(request, 'grades/monthlyGradeUpdate.html', {'groups': groups,
                                                              'students': students,
                                                              'subjects': subjects,
                                                              'months': month,
                                                              'month_grades': month_grades,
                                                              'monthlyGrades': monthlyGrades,
                                                                })


@login_required
def monthlyGradeList(request):
    subjects = Subject.objects.order_by('name')  # Query all subjects ordered by name
    groups = Group.objects.order_by('name')  # Query all groups ordered by name
    students = Student.objects.order_by('id_number')  # Query all students ordered by id_number
    monthlyGrades = MonthlyGrade.objects.order_by('group')  # Query all monthly grades ordered by group
    month = SCHOOL_YEAR
    month_grades = MONTH_GRADES

    return render(request, 'grades/monthlyGradeList.html', {'groups': groups,
                                                            'students': students,
                                                            'subjects': subjects,
                                                            'months': month,
                                                            'month_grades': month_grades,
                                                            'monthlyGrades': monthlyGrades,
                                                                })


@login_required
def studentsAndGrades(request):
    group_id = request.GET.get('group')  # Get group ID from GET parameters
    month = request.GET.get('month')  # Get month from GET parameters
    subject_id = request.GET.get('subject')  # Get subject ID from GET parameters

    group = get_object_or_404(Group, id=group_id)  # Get group object by ID or return 404 error
    subject = get_object_or_404(Subject, id=subject_id)  # Get subject object by ID or return 404 error
    grades = MonthlyGrade.objects.filter(group=group, month=month, subject=subject)  # Query monthly grades filtered by group, month, and subject

    data = []
    for grade in grades:
        data.append({
            'student': {
                'id': grade.student.id,
                'id_number': grade.student.id_number,
                'name': grade.student.name,
                'last_name': grade.student.last_name,
            },
            'group': grade.group.name,
            'month': grade.month,
            'subject': grade.subject.name,
            'month_grade': grade.month_grade,
            'month_grade_display': MONTH_GRADES.get(grade.month_grade, 'Unknown'), # Get month grade display from MONTH_GRADES dictionary
        })

    return JsonResponse(data, safe=False)  # Return JSON response with data list


@login_required
def subjectsAndGrades(request):
    group_id = request.GET.get('group')  # Get group ID from GET parameters
    month = request.GET.get('month')  # Get month from GET parameters
    student_id = request.GET.get('student')  # Get student ID from GET parameters

    group = get_object_or_404(Group, id=group_id)  # Get group object by ID or return 404 error
    student = get_object_or_404(Student, id=student_id)  # Get student object by ID or return 404 error
    grades = MonthlyGrade.objects.filter(group=group, month=month, student=student)  # Query monthly grades filtered by group, month, and student

    data = []
    for grade in grades:
        data.append({
            'subject': {
                'id': grade.subject.id,
                'name': grade.subject.name,
            },
            'student': grade.student.id_number,
            'group': grade.group.name,
            'month': grade.month,
            'month_grade': grade.month_grade,
            'month_grade_display': MONTH_GRADES.get(grade.month_grade, 'Unknown'),  # Get month grade display from MONTH_GRADES dictionary
        })

    return JsonResponse(data, safe=False)  # Return JSON response with data list


@login_required
def monthlyGradeDelete(request, id):
    monthlyGrade = get_object_or_404(MonthlyGrade, pk=id)  # Get monthly grade by ID or return 404 error
    if monthlyGrade:
        monthlyGrade.delete()  # Delete monthly grade if exists
    return redirect('monthlyGradeUpdate')  # Redirect to 'monthlyGradeUpdate' URL after deletion


@login_required
@csrf_exempt
def saveMonthlyGrade(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)  # Parse JSON data from request body

            group = get_object_or_404(Group, id=data.get('group'))  # Get group object by ID or return 404 error
            student = get_object_or_404(Student, id=data.get('student_id'))  # Get student object by ID or return 404 error
            subject = get_object_or_404(Subject, id=data.get('subject'))  # Get subject object by ID or return 404 error
            month = data.get('month')  # Get month from JSON data
            grade = data.get('grade')  # Get grade from JSON data

            # Save or update the student's monthly grade
            student_grade, create = MonthlyGrade.objects.update_or_create(
                month=month,
                month_grade=grade,
                group=group,
                student=student,
                subject=subject,
            )

            return JsonResponse({'message': 'Grade saved successfully'}, status=200)  # Return success message in JSON response
        except Exception as e:
            return JsonResponse({'message': 'Failed to save grade', 'error': str(e)}, status=400)  # Return error message in JSON response
    else:
        return JsonResponse({'message': 'Invalid request method'}, status=405)  # Return error for invalid request method


@login_required
@csrf_exempt
def updateMonthlyGrade(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)  # Parse JSON data from request body

            group = get_object_or_404(Group, id=data.get('group'))  # Get group object by ID or return 404 error
            student = get_object_or_404(Student, id=data.get('student_id'))  # Get student object by ID or return 404 error
            subject = get_object_or_404(Subject, id=data.get('subject'))  # Get subject object by ID or return 404 error
            month = data.get('month')  # Get month from JSON data
            month_grade = data.get('grade')  # Get grade from JSON data

            # Update or create the student's monthly grade
            student_grade, created = MonthlyGrade.objects.update_or_create(
                group=group,
                student=student,
                subject=subject,
                month=month,
                defaults={'month_grade': month_grade}
            )

            return JsonResponse({'message': 'Grade updated successfully'}, status=200)  # Return success message in JSON response
        except Exception as e:
            return JsonResponse({'message': 'Failed to update grade', 'error': str(e)}, status=400)  # Return error message in JSON response
    else:
        return JsonResponse({'message': 'Invalid request method'}, status=405)  # Return error for invalid request method


@login_required
def subjectsByGroup(request):
    group_id = request.GET.get('group')  # Get group ID from GET parameters
    if group_id:
        subjects = Subject.objects.filter(group_id=group_id).values('id', 'name')  # Filter subjects by group ID and retrieve id and name fields
        return JsonResponse(list(subjects), safe=False)  # Return JSON response with list of subjects
    else:
        return JsonResponse([], safe=False)  # Return empty JSON response if group ID is not provided

def studentsByGroup(request):
    group_id = request.GET.get('group')  # Get group ID from GET parameters
    if group_id:
        students = Student.objects.filter(group_id=group_id).values('id', 'id_number', 'name', 'last_name').order_by('id_number')  # Filter students by group ID and retrieve id, id_number, name, and last_name fields, ordered by id_number
        return JsonResponse(list(students), safe=False)  # Return JSON response with list of students
    else:
        return JsonResponse([], safe=False)  # Return empty JSON response if group ID is not provided
