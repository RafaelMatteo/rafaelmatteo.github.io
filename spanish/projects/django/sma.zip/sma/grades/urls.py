# ratings/urls.py

from django.urls import path

from grades.views import monthlyGradeAssign, monthlyGradeDelete, monthlyGradeList, monthlyGradeUpdate, saveMonthlyGrade, studentsAndGrades, studentsByGroup, subjectsAndGrades, subjectsByGroup, updateMonthlyGrade



urlpatterns = [
    path('monthlyGradeAssign/', monthlyGradeAssign, name='monthlyGradeAssign'),
    path('monthlyGradeUpdate/', monthlyGradeUpdate, name='monthlyGradeUpdate'),
    path('monthlyGradeList/', monthlyGradeList, name='monthlyGradeList'),
    path('monthlyGradeDelete/', monthlyGradeDelete, name='monthlyGradeDelete'),
    path('saveMonthlyGrade/', saveMonthlyGrade, name='saveMonthlyGrade'),
    path('updateMonthlyGrade/', updateMonthlyGrade, name='updateMonthlyGrade'),
    path('studentsAndGrades/', studentsAndGrades, name='studentsAndGrades'),
    path('studentsByGroup/', studentsByGroup, name='studentsByGroup'),
    path('subjectsAndGrades/', subjectsAndGrades, name='subjectsAndGrades'),
    path('subjectsByGroup/', subjectsByGroup, name='subjectsByGroup'),
]