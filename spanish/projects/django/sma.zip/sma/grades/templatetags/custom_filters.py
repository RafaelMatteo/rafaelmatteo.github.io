# grades/templatetags/custom_filters.py
from django import template

register = template.Library()  # Register the template library

# Custom template filter to retrieve a value from a dictionary using a key
@register.filter
def get_dict_value(dictionary, key):
    return dictionary.get(key, '')  # Return the value for the given key from the dictionary, or an empty string if the key does not exist
