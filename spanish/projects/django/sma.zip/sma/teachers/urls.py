# teachers/urls.py

from django.urls import path
from teachers.views import teacherCreation, teacherDelete, teacherDetails, teacherList, teacherUpdate


urlpatterns = [
    path('teacherList', teacherList, name='teacherList'),
    path('teacherCreation', teacherCreation, name='teacherCreation'),
    path('teacherDetails/<int:id>', teacherDetails, name='teacherDetails'),
    path('teacherUpdate/<int:id>', teacherUpdate, name='teacherUpdate'),
    path('teacherDelete/<int:id>', teacherDelete, name='teacherDelete'),
]