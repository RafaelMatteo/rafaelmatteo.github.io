# teachers/admin.py

from django.contrib import admin
from teachers.models import Teacher

# Register the Teacher model with the Django admin site
admin.site.register(Teacher)