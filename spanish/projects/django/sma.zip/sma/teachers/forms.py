# teachers/forms.py

from django.forms import EmailInput, ModelForm
from teachers.models import Teacher


class TeacherCreationForm(ModelForm):
    class Meta:
        model = Teacher
        fields = '__all__'  # Fields of the Teacher model are included in the form.
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})  # Sets the email field to use an email input type.
        }

class TeacherChangeForm(ModelForm):
    class Meta:
        model = Teacher
        fields = '__all__'  # Fields of the Teacher model are included in the form.
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})  # Sets the email field to use an email input type.
        }