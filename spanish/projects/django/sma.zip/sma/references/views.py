# references/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from references.forms import Reference, ReferenceChangeForm, ReferenceCreationForm


@login_required
def referenceList(request):
    references = Reference.objects.order_by('id_number')  # Query all references and order them by id_number
    total_references = Reference.objects.count()  # Count total number of references
    return render(request, 'references/referenceList.html', {'references': references, 'total_references': total_references})
    # Render the template with references and total_references count


@login_required
def referenceDetails(request, id):
    reference = get_object_or_404(Reference, pk=id)  # Get the reference instance by its primary key
    return render(request, 'references/referenceDetails.html', {'reference': reference})
    # Render the template with the reference details


@login_required
def referenceCreation(request):
    if request.method == 'POST':
        form = ReferenceCreationForm(request.POST)  # Bind POST data to ReferenceCreationForm
        if form.is_valid():
            form.save()  # Save the form data to create a new Reference instance
            return redirect('studentCreation')  # Redirect to student creation page after successful creation
    else:
        form = ReferenceCreationForm()  # Create a new instance of ReferenceCreationForm for GET requests

    return render(request, 'references/referenceCreation.html', {'form': form})
    # Render the template with the form for creating a new reference


@login_required
def referenceUpdate(request, id):
    reference = get_object_or_404(Reference, pk=id)  # Get the reference instance by primary key
    if request.method == 'POST':
        form = ReferenceChangeForm(request.POST, instance=reference)  # Bind POST data to ReferenceChangeForm with instance
        if form.is_valid():
            form.save()  # Save the form data to update the existing Reference instance
            return redirect('referenceList')  # Redirect to reference list page after successful update
    else:
        form = ReferenceChangeForm(instance=reference)  # Create a form instance for the existing reference instance

    return render(request, 'references/referenceUpdate.html', {'form': form})
    # Render the template with the form for updating an existing reference


@login_required
def referenceDelete(request, id):
    reference = get_object_or_404(Reference, pk=id)  # Get the reference instance by primary key
    if reference:
        reference.delete()  # Delete the reference instance
    return redirect('referenceList')  # Redirect to reference list page after deletion