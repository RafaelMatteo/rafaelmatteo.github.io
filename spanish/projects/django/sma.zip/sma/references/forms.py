# references/forms.py

from django.forms import EmailInput, ModelForm
from references.models import Reference


# Form for creating new instances of Reference
class ReferenceCreationForm(ModelForm):

    class Meta:
        model = Reference  # Model for form generation
        fields = '__all__'  # Fields from Reference model in the form
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})  # Use EmailInput widget for email field with email type
        }


# Form for updating existing instances of Reference
class ReferenceChangeForm(ModelForm):

    class Meta:
        model = Reference  # Model for form generation
        fields = '__all__'  # Fields from Reference model in the form
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})  # Use EmailInput widget for email field with email type
        }