# references/admin.py

from django.contrib import admin
from references.models import Reference


# Register the Reference model for administration
admin.site.register(Reference)