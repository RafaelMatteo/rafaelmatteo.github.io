# students/models.py

from django.db import models
from common.models import Person
from references.models import Reference
from groups.models import Group
from degrees.models import Degree


class Student(Person):
    admission_date = models.DateField()
    degree = models.ForeignKey(Degree, related_name='students', on_delete=models.CASCADE)
    group = models.ForeignKey(Group, related_name='students', on_delete=models.CASCADE)
    reference = models.ForeignKey(Reference, related_name='references', on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.name} {self.last_name}, {self.degree}'