# students/admin

from django.contrib import admin
from students.models import Student


# Register the Student model for administration
admin.site.register(Student)



