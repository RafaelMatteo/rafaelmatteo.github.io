# students/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from students.forms import Student, StudentChangeForm, StudentCreationForm
from references.forms import Reference


@login_required
def studentList(request):
    """
    Displays a list of all students.
    """
    students = Student.objects.order_by('id_number') # Student model
    total_students = Student.objects.count()
    return render(request, 'students/studentList.html', {'students': students, 'total_students': total_students})


@login_required
def studentDetails(request, id):
    """
    Displays details of a specific student.
    """
    student = get_object_or_404(Student, pk=id)
    return render(request, 'students/studentDetails.html', {'student': student})


@login_required
def studentCreation(request):
    """
    Handles creation of a new student.
    """
    references = Reference.objects.order_by('id_number')  # Reference model
    if request.method == 'POST':
        form = StudentCreationForm(request.POST)
        if form.is_valid():
            student = form.save(commit=False)
            student.reference_id = request.POST.get('reference')
            if student.reference_id:
                student.save()
                return redirect('studentList')
            else:
                form.add_error('reference', 'Reference ID is required!')
    else:
        form = StudentCreationForm()

    return render(request, 'students/studentCreation.html', {'form': form, 'references': references})


@login_required
def studentUpdate(request, id):
    """
    Handles updating an existing student by id
    """
    student = get_object_or_404(Student, pk=id)
    if request.method == 'POST':
        form = StudentChangeForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('studentList')
    else:
        form = StudentChangeForm(instance=student)

    return render(request, 'students/studentUpdate.html', {'form': form})


@login_required
def studentDelete(request, id):
    """
    Handles deletion of an existing student by id
    """
    student = get_object_or_404(Student, pk=id)
    if student:
        student.delete()
    return redirect('studentList')
