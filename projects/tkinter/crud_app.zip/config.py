# config.py
# This file contains global settings and constants

# Application name and version
APP_NAME = 'CRUD Application'
VERSION = 'V:2'

# Database Configuration
DB_DIR = 'data'
DB_NAME = 'UsersDB.sqlite'
# DB_USER = ""
# DB_PASSWORD = "12345"

# GUI Configuration
WINDOW_WIDTH = 310
WINDOW_HEIGHT = 345
TITLE = (f'{APP_NAME} - {VERSION}')
ENTRY_BACKGROUND = '#ffa500' # Orange color
ENTRY_FOREGROUND = '#000000' # Black color (text)

