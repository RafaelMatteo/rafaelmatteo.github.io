# main.py


from tkinter import Tk
from gui.app import App

def main():
    # Create the main window (root) of the Tkinter application
    root = Tk()
    
    # Initialize the application interface with the root window
    app_interface = App(root)
    
    # Start the Tkinter event loop, waiting for user interaction
    root.mainloop()

# The script is executed directly
if __name__ == "__main__":
    main()