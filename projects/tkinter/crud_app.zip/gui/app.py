# gui/app.py

import config
from tkinter import Menu, StringVar, Label, Entry, Button, Frame, messagebox
from logic.logic import Conection
from gui.all_records import AllRecordsWindow
from gui.about import AboutWindow


class App:
    
    
    def __init__(self, root):
        # Initialize the main application window
        self.root = root
        self.root.title(config.TITLE)
        self.root.geometry(f'{config.WINDOW_WIDTH}x{config.WINDOW_HEIGHT}')
        
        # Initialize the database connection
        self.conection = Conection(self)
        self.conection.count_database_records()
        
        self.entry_fields = {}
        self.buttons = {}

        # Components of the UI creation
        self.menu_creation()
        self.labels_and_entrys_creation()
        self.button_all_records()
        self.buttons_crud_creation()
        self.statusbar_creation()
    
    
    def menu_creation(self):
        # Menu Bar creation  
        menu_bar = Menu(self.root)
        
        # Menu CRUD creation
        crud = Menu(menu_bar, tearoff=0)
        crud.add_command(label="Create", command=self.conection.create)
        crud.add_command(label="Read", command=self.conection.read)
        crud.add_command(label="Update", command=self.conection.update)
        crud.add_command(label="Delete", command=self.conection.delete)
        crud.add_separator()
        crud.add_command(label="Quit", command=self.quit_application)
        menu_bar.add_cascade(label="CRUD", menu=crud)
        
        # Menu Edit creation
        edit = Menu(menu_bar, tearoff=0)
        edit.add_command(label="Clear fields", command=self.clear_entry_fields)
        menu_bar.add_cascade(label="Edit", menu=edit)
        
        # Menu Database creation
        data_base = Menu(menu_bar, tearoff=0)
        data_base.add_command(label="Create Database", command=lambda: (self.conection.database_creation(), 
                              self.update_status(f'Total records in Database: {self.conection.count_database_records()}')))
        menu_bar.add_cascade(label="Data Base", menu=data_base)
        
        # Menu Help creation
        help = Menu(menu_bar, tearoff=0)
        help.add_command(label="About me...", command = AboutWindow)
        menu_bar.add_cascade(label="Help", menu=help)

        # Set the menu bar in the root window
        self.root.config(menu=menu_bar)
        
        return
    
    
    def labels_and_entrys_creation(self):
        # Create labels and entry fields for the form
        labels = {1: 'Id', 2: 'Name', 3: 'Surname', 4: 'Address', 5: 'City', 6: 'Country', 7: 'Password'}
        self.entry_vars = {}
        
        for row, label_text in labels.items():
            label = Label(self.root, text=label_text)
            label.grid(column=0, row=row, pady=5, padx=10, sticky='w')
            
            var = StringVar()
                      
            self.entry_vars[f'var_{label_text.strip()}'] = var
            
            if label_text == 'Password':
                entry = Entry(
                    self.root, 
                    textvariable=var, 
                    show='*',
                    background=config.ENTRY_BACKGROUND, 
                    foreground=config.ENTRY_FOREGROUND,
                    justify='right'
                )
            else:
                entry = Entry(
                    self.root, 
                    textvariable=var,
                    background=config.ENTRY_BACKGROUND, 
                    foreground=config.ENTRY_FOREGROUND,
                    justify='right'
                )
                
            entry.grid(column=1, row=row, pady=5)            
            self.entry_fields[f'entry_{label_text.strip()}'] = entry
            
        return
    
    
    def button_all_records(self):
        # Create a button to view all records
        button_all_records = Button(self.root, text='See all records', command=AllRecordsWindow)
        button_all_records.place(x=20, y=240, width=270)
        
        return
    
    
    def buttons_crud_creation(self):
        # Create CRUD buttons
        commands = {'create': lambda: self.conection.create(), 
                  'read': lambda: self.button_read_pressed(), 
                  'update': lambda: self.conection.update(), 
                  'delete': lambda: self.conection.delete()}
        x = 20
        
        for button_text, command in commands.items():
                        
            button = Button(self.root, text=button_text.capitalize(), command=command)
            button.place(x=x, y=280, width=60)
            x+=70
            
            self.buttons[f'button_{button_text.strip()}'] = button
            
        return
    
    
    def statusbar_creation(self):
        # Create the status bar
        self.status_frame = Frame(self.root, relief='sunken', bd=1)
        
        records = self.conection.count_database_records()
        
        self.status_label = Label(self.status_frame, text=f'Total records in Database: {records}' , anchor='e')
        self.status_label.pack(fill='x', padx=5)   
        self.status_frame.place(x=1, y=320, width=308)
        
        return


    def update_status(self, message):
        # Update the status bar message
        self.status_label.config(text=message)
        
        return
    
    
    def quit_application(self):
        # Quit the application after confirmation
        value = messagebox.askquestion(config.APP_NAME, "Sure you want to leave?")
        if value == "yes":
            self.root.destroy()
        
        return
    
    
    def clear_entry_fields(self):
        # Clear all entry fields
        for var in self.entry_vars.values():
            var.set('')
        
        return
    
    
    def button_create_pressed(self):
        # Get values from entry fields for creating a new record
        values = {key: var.get() for key, var in self.entry_vars.items()}
        
        return values
    
    
    def fill_entry_fields(self, user):
        # Fill entry fields with user data
        for var , user_item in zip(self.entry_vars.values(), user):
            var.set(user_item)
        
        return
    
    
    def button_read_pressed(self):
        # Get the ID value from entry field and read the record
        entry_id = self.entry_vars.get('var_Id')

        if entry_id:
            entry_value = entry_id.get()
            user = self.conection.read(entry_value)
            self.fill_entry_fields(user)
        else:
            messagebox.showwarning("Warning", "Entry Id not found!")
            
        return
    
    
    def button_update_pressed(self):
        # Get values from entry fields for updating a record
        values = {key: var.get() for key, var in self.entry_vars.items()}
        
        return values
    
    
    def button_delete_pressed(self):
        # Get values from entry fields for deleting a record
        values = {key: var.get() for key, var in self.entry_vars.items()}
        
        return values