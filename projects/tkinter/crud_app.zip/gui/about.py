# gui/about.py

import tkinter as tk

class AboutWindow(tk.Toplevel):
    
    def __init__(self, master=None):
        super().__init__(master)
        self.title("About me...")
        self.geometry("400x200")  # Set the size of the secondary window
        
        # Label with the developer's name to the secondary window
        developer_label = tk.Label(self, 
                                   text="Developer: Rafael Matteo Mourigan.",
                                   font=('Arial',16, 'bold'),
                                   fg='orange'
                                   )
        developer_label.pack(pady=10)
        
        # Label with the LinkedIn profile
        linkedin_label = tk.Label(self, text="LinkedIn: https://www.linkedin.com/in/rjmatteomourigan/")
        linkedin_label.pack(pady=5)
        
        # Label with the contact phone number
        contact_label = tk.Label(self, text="Phone: +598 91 667 422")
        contact_label.pack(pady=5)
        
        # Label with the contact city and country
        country_label = tk.Label(self, text="Country: Las Piedras, Canelones, Uruguay.")
        country_label.pack(pady=5)
        
        # Close the secondary window
        cerrar_btn = tk.Button(self, text="Cerrar", command=self.destroy)
        cerrar_btn.pack(pady=10)