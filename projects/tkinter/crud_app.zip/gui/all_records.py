# gui/all_records.py

import tkinter as tk
import config
from logic.logic import Conection

class AllRecordsWindow(tk.Toplevel):
    
    
    def __init__(self, master=None):
        
        # Initialize the database connection
        self.conection = Conection(self)
        
        super().__init__(master)
        self.title(f'{config.APP_NAME} - All records')
        self.geometry("400x200") # Set the size of the secondary window
        
        # Add a subtitle label
        subtitle = tk.Label(self, text="All records in Database:")
        subtitle.pack(pady=10)
        
         # Get all records from the database
        records = self.conection.see_all_records()
        
        # Create a Listbox to display the records
        listbox_records = tk.Listbox(self, bg=config.ENTRY_BACKGROUND, fg=config.ENTRY_FOREGROUND)
        listbox_records.pack(padx=5, pady=10, expand=True, fill=tk.BOTH)
        
         # Add the records to the Listbox
        for record in records:
            listbox_records.insert(tk.END, record)
        
        # Close the secondary window
        close_btn = tk.Button(self, text="Close", command=self.destroy)
        close_btn.pack(pady=10)