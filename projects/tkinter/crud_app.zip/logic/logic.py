# logic/logic.py

import config
from tkinter import messagebox
import sqlite3
import os


class Conection():
    
    
    # Initialize the class with the root of the Tkinter application 
    def __init__(self, root): 
        
        self.root = root
        
        # Create the database directory if it does not exist   
        if not os.path.exists(config.DB_DIR):
            os.makedirs(config.DB_DIR)
    
    
    def database_creation(self):
        # Define the full path of the database
        db_path = os.path.join(config.DB_DIR, config.DB_NAME)
        
        # Connect to the database and create a table if it does not exist
        with sqlite3.connect(db_path) as conection:
            cursor = conection.cursor()
    
            try:
                # Create the USERSDATA table
                cursor.execute('''
                    CREATE TABLE USERSDATA (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Name VARCHAR(50),
                        Surname VARCHAR(50),
                        Address VARCHAR(50),
                        City VARCHAR(50),
                        Country VARCHAR(50),
                        Password VARCHAR(20)
                    )
                    ''')
                messagebox.showinfo('Database Conection', 'Database successfully created!')
            except:
                # Show a warning if the table already exists
                messagebox.showwarning('Database Conection', 'Database already exsists!!!')
            finally:
                cursor.close()
        
        return
    
    
    def count_database_records(self):
        # Define the full path of the database
        db_path = os.path.join(config.DB_DIR, config.DB_NAME)
          
        # Connect to the database and count the records in the USERSDATA table
        with sqlite3.connect(db_path) as conection:
            cursor = conection.cursor()
    
            try:
                cursor.execute('''SELECT COUNT(*) FROM USERSDATA''')
                total = cursor.fetchone()[0] 
            except Exception as e:
                total = "Database Error!!!"
            finally:
                cursor.close()
                
        return total
    
    
    def see_all_records(self):
        # Define the full path of the database
        db_path = os.path.join(config.DB_DIR, config.DB_NAME)
        
        # Connect to the database and get all records from the USERSDATA table
        with sqlite3.connect(db_path) as conection:
            cursor = conection.cursor()
    
            try:
                cursor.execute("SELECT Id, Name, Surname, Address, City, Country FROM USERSDATA")
                records = cursor.fetchall()
            except Exception as e:
                messagebox.showwarning(config.APP_NAME, f"No Records found!!!" + str(e))
            finally:
                cursor.close()
                
        return records
    
    
    def create(self):
        # Get the entry values from the user interface
        entry_values = self.root.button_create_pressed()
        
        # Define the full path of the database
        db_path = os.path.join(config.DB_DIR, config.DB_NAME)

        # Connect to the database and add a new record to the USERSDATA table
        with sqlite3.connect(db_path) as conection:
            cursor = conection.cursor()
            try:
                entry_data = (entry_values['var_Name'], entry_values['var_Surname'], 
                    entry_values['var_Address'], entry_values['var_City'], entry_values['var_Country'],
                    entry_values['var_Password'])
                cursor.execute(
                    "INSERT INTO USERSDATA (Name, Surname, Address, City, Country, PASSWORD) VALUES (?, ?, ?, ?, ?, ?)", entry_data
                )
                conection.commit()
                # After INSERT, clear all entry fields
                self.root.clear_entry_fields()
                records = self.count_database_records()
                self.root.update_status(f'Total records in Database: {records}')
                messagebox.showinfo(config.APP_NAME, "Record successfully created!")
            except Exception as e:
                messagebox.showwarning(config.APP_NAME, f"Error creating record: {e}")
                 
        return
    
    
    def read(self, entry_id_value):
        # Define the full path of the database
        db_path = os.path.join(config.DB_DIR, config.DB_NAME)
        
        # Connect to the database and get a specific record from the USERSDATA table by ID
        with sqlite3.connect(db_path) as conection:
            cursor = conection.cursor()
        
            try:
                cursor.execute("SELECT * FROM USERSDATA WHERE ID = " + entry_id_value)
                user = cursor.fetchall()
                
                return user[0]
            
            except KeyError as e:
                messagebox.showerror("Error", f"Entry Id not found!: {e}")
            except Exception as e:
                messagebox.showerror("Error", f"An unexpected error occurred!: {e}")
                
        return
    
    
    def update(self):
        # Get the entry values from the user interface
        entry_values = self.root.button_update_pressed()
        
        # Define the full path of the database
        db_path = os.path.join(config.DB_DIR, config.DB_NAME)

        # Connect to the database and update a specific record in the USERSDATA table
        with sqlite3.connect(db_path) as conection:
            cursor = conection.cursor()
            
            try:
                entry_data = (entry_values['var_Name'], entry_values['var_Surname'], entry_values['var_Address'],
                            entry_values['var_City'], entry_values['var_Country'], entry_values['var_Password'])
                
                cursor.execute(
                    "UPDATE USERSDATA SET Name = ?, Surname = ?, Address = ?, City = ?, Country = ?, Password = ? WHERE Id = " + 
                    entry_values['var_Id'], entry_data
                )
                conection.commit()
                self.root.clear_entry_fields()
                records = self.count_database_records()
                self.root.update_status(f'Total records in Database: {records}')
                messagebox.showinfo(config.APP_NAME, "Record successfully updated!")
            except Exception as e:
                messagebox.showwarning(config.APP_NAME, f"Error updating record: {e}")
                
        return
    
    
    def delete(self):
        # Get the entry values from the user interface
        entry_values = self.root.button_delete_pressed()
        
        # Define the full path of the database
        db_path = os.path.join(config.DB_DIR, config.DB_NAME)

        # Connect to the database and delete a specific record in the USERSDATA table by ID
        with sqlite3.connect(db_path) as conection:
            cursor = conection.cursor()
            
            try:
                cursor.execute("DELETE FROM USERSDATA WHERE ID = " + entry_values['var_Id'])
                conection.commit()
                self.root.clear_entry_fields()
                records = self.count_database_records()
                self.root.update_status(f'Total records in Database: {records}')
                messagebox.showinfo(config.APP_NAME, "Record successfully deleted!")
            except Exception as e:
                messagebox.showwarning(config.APP_NAME, f"Error deleting record: {e}")
                
        return