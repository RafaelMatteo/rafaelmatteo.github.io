from django.contrib import admin
from degrees.models import Degree

# Register your models here.
admin.site.register(Degree)