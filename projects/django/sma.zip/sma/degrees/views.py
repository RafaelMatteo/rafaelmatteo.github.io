# degrees/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required

from degrees.forms import DegreeCreationForm, DegreeChangeForm
from degrees.models import Degree


@login_required
def degreeList(request):
    degrees = Degree.objects.order_by('name')
    total_degrees = Degree.objects.count()
    return render(request, 'degrees/degreeList.html', {'degrees': degrees, 'total_degrees': total_degrees})
    

@login_required
def degreeDetails(request, id):
    degree = get_object_or_404(Degree, pk=id)
            
    return render(request, 'degrees/degreeDetails.html', {'degree': degree})
    
    
@login_required
def degreeCreation(request):
    if request.method == 'POST':
       form = DegreeCreationForm(request.POST)
       if form.is_valid():
            form.save()
            return redirect('degreeList')
    else:
        form = DegreeCreationForm()

    return render(request, 'degrees/degreeCreation.html', {'form': form})
    

@login_required
def degreeUpdate(request, id):
    degree = get_object_or_404(Degree, pk=id)
    if request.method == 'POST':
        form = DegreeChangeForm(request.POST, instance=degree)
        if form.is_valid():
            form.save()
            return redirect('degreeList')
    else:
        form = DegreeChangeForm(instance=degree)
 
    return render(request, 'degrees/degreeUpdate.html', {'form': form})


@login_required
def degreeDelete(request, id):
    degree = get_object_or_404(Degree, pk=id)
    if degree:
        degree.delete()
    return redirect('degreeList')