# degrees/urls.py

from django.urls import path
from degrees.views import degreeCreation, degreeDelete, degreeDetails, degreeList, degreeUpdate


urlpatterns = [
    path('degreeList/', degreeList, name='degreeList'),
    path('degreeCreation/', degreeCreation, name='degreeCreation'),
    path('degreeDetails/<int:id>', degreeDetails, name='degreeDetails'),
    path('degreeUpdate/<int:id>', degreeUpdate, name='degreeUpdate'),
    path('degreeDelete/<int:id>', degreeDelete, name='degreeDelete'),
]