# degrees/forms.py

from django.forms import ModelForm
from degrees.models import Degree


class DegreeCreationForm(ModelForm):

    class Meta:
        model = Degree
        fields = '__all__'


class DegreeChangeForm(ModelForm):

    class Meta:
        model = Degree
        fields = '__all__'
