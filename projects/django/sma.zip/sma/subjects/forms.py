# subjects/forms.py

from django.forms import ModelForm
from subjects.models import Subject


class SubjectCreationForm(ModelForm):
    
    class Meta:
        model = Subject
        fields = '__all__'
        
        
class SubjectChangeForm(ModelForm):

    class Meta:
        model = Subject
        fields = '__all__'
