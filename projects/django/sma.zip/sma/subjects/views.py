# subjects/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from subjects.forms import SubjectChangeForm, SubjectCreationForm
from teachers.models import Teacher
from groups.models import Group
from subjects.models import Subject


@login_required
def subjectList(request):
    subjects = Subject.objects.order_by('group')
    total_subjects = Subject.objects.count()
    return render(request, 'subjects/subjectList.html', {'subjects': subjects, 'total_subjects': total_subjects})
    

@login_required
def subjectDetails(request, id):
    subject = get_object_or_404(Subject, pk=id)
    return render(request, 'subjects/subjectDetails.html', {'subject': subject})


@login_required
def subjectCreation(request):
    if request.method == 'POST':
        form = SubjectCreationForm(request.POST)
        if form.is_valid():   
            form.save()
            return redirect('subjectList')
    else:
        form = SubjectCreationForm()

    return render(request, 'subjects/subjectCreation.html', {'form': form})
   

@login_required
def subjectUpdate(request, id):
    subject = get_object_or_404(Subject, pk=id)
    if request.method == 'POST':
        form = SubjectChangeForm(request.POST, instance=subject)
        if form.is_valid():
            form.save()
            return redirect('subjectList')
    else:
        form = SubjectChangeForm(instance=subject)

    return render(request, 'subjects/subjectUpdate.html', {'form': form})


@login_required
def subjectDelete(request, id):
    subject = get_object_or_404(Subject, pk=id)
    if subject:
        subject.delete()
    return redirect('subjectList')


def assignSubjectToGroups(request):
    if request.method == 'POST':
        subject_name = request.POST['subject_name']
        teacher_id = request.POST['teacher_id']
        group_ids = request.POST.getlist('group_ids')

        teacher = Teacher.objects.get(id=teacher_id)
        
        for group_id in group_ids:
            group = Group.objects.get(id=group_id)
            subject = Subject(name=subject_name, group=group, teacher=teacher)
            subject.save()
            messages.success(request, "Subject assigned successfully!")
        
        return redirect('degreeList')  
    else:
        groups = Group.objects.all().order_by('name')
        teachers = Teacher.objects.all()
        
        return render(request, 'subjects/assignSubjects.html', {'groups': groups, 'teachers': teachers})