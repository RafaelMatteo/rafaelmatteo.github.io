# subjects/models.py

from django.db import models
from groups.models import Group
from teachers.models import Teacher


class Subject(models.Model):
    name = models.CharField(max_length=150)
    group = models.ForeignKey(Group, related_name='subjects', on_delete=models.CASCADE)
    teacher = models.ForeignKey(Teacher, related_name='subjects', on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.name}'