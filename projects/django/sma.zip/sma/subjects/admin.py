# subjects/admin.py

from django.contrib import admin
from subjects.models import Subject

# Register your models here.
admin.site.register(Subject)