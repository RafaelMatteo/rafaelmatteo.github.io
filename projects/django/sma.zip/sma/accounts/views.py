# accounts/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
# from datetime import datetime
from accounts.models import CustomUser

# from grades.models import Grade
# from subjects.models import Subject
# from students.models import Student
# from teachers.models import Teacher
# from references.models import Reference
# from groups.models import Group
from accounts.forms import CustomUserChangeForm, CustomUserCreationForm


# @login_required
# def home(request):
#     total_users = CustomUser.objects.count()
#     total_students = Student.objects.count()
#     total_teachers = Teacher.objects.count()
#     total_references = Reference.objects.count()
#     total_grades = Grade.objects.count()
#     total_subjects = Subject.objects.count()
#     total_groups = Group.objects.count()
#     date = datetime.now().strftime('%A, %d %B %Y')
#     return render(request, 'home.html', {'total_users': total_users, 
#                                          'total_students': total_students,
#                                          'total_teachers': total_teachers,
#                                          'total_references': total_references,
#                                          'total_grades': total_grades,
#                                          'total_subjects': total_subjects,
#                                          'total_groups': total_groups,
#                                          'date': date})


@login_required
def userList(request):
    users = CustomUser.objects.order_by('id_number')
    total_users = CustomUser.objects.count()
    return render(request, 'users/userList.html', {'users': users, 'total_users': total_users})
    

@login_required  
def userDetails(request, id):
    user = get_object_or_404(CustomUser, pk=id)
    return render(request, 'users/userDetails.html', {'user': user})


@login_required
def userCreation(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = CustomUserCreationForm()

    return render(request, 'users/userCreation.html', {'form': form})
    

@login_required
def userUpdate(request, id):
    user = get_object_or_404(CustomUser, pk=id)
    if request.method == 'POST':
        form = CustomUserChangeForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('userList')
    else:
        form = CustomUserChangeForm(instance=user)

    return render(request, 'users/userUpdate.html', {'form': form})


@login_required
def userDelete(request, id):
    user = get_object_or_404(CustomUser, pk=id)
    if user:
        user.delete()
    return redirect('userList')