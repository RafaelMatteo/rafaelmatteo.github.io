# accounts/urls.py

from django.urls import path

from accounts.views import userCreation, userDelete, userDetails, userList, userUpdate

urlpatterns = [
    # path('', home, name="home"),
    path('userList/', userList, name='userList'),
    path('userCreation/', userCreation, name='userCreation'),
    path('userDetails/<int:id>', userDetails, name='userDetails'),
    path('userUpdate/<int:id>', userUpdate, name='userUpdate'),
    path('userDelete/<int:id>', userDelete, name='userDelete'),
]