# accounts/forms.py

from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.forms import EmailInput

from .models import CustomUser

class CustomUserCreationForm(UserCreationForm):

    class Meta:
        model = CustomUser
        fields = '__all__'
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})
        }

class CustomUserChangeForm(UserChangeForm):

    class Meta:
        model = CustomUser
        fields = '__all__'
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})
        }