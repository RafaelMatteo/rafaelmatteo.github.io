# groups/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from groups.forms import GroupCreationForm, GroupChangeForm
from groups.models import Group


@login_required
def groupList(request):
    groups = Group.objects.order_by('name')
    total_groups = Group.objects.count()
    return render(request, 'groups/groupList.html', {'groups': groups, 'total_groups': total_groups})
    

@login_required
def groupDetails(request, id):
    group = get_object_or_404(Group, pk=id)
    subjects = group.subjects.all()
    students = group.students.order_by('id_number')
    
    return render(request, 'groups/groupDetails.html', {'group': group, 'subjects': subjects, 'students': students})


@login_required
def groupCreation(request):
    if request.method == 'POST':
       form = GroupCreationForm(request.POST)
       if form.is_valid():
            form.save()
            return redirect('groupList')
    else:
        form = GroupCreationForm()

    return render(request, 'groups/groupCreation.html', {'form': form})
    

@login_required
def groupUpdate(request, id):
    group = get_object_or_404(Group, pk=id)
    if request.method == 'POST':
        form = GroupChangeForm(request.POST, instance=group)
        if form.is_valid():
            form.save()
            return redirect('groupList')
    else:
        form = GroupChangeForm(instance=group)
 
    return render(request, 'groups/groupUpdate.html', {'form': form})


@login_required
def groupDelete(request, id):
    group = get_object_or_404(Group, pk=id)
    if group:
        group.delete()
    return redirect('groupList')