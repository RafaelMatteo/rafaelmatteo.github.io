# groups/forms.py

from django.forms import ModelForm
from groups.models import Group


class GroupCreationForm(ModelForm):
    
    class Meta:
        model = Group
        fields = '__all__'
        
        
class GroupChangeForm(ModelForm):

    class Meta:
        model = Group
        fields = '__all__'