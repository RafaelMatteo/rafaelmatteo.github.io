# groups/models.py

from django.db import models
from degrees.models import Degree


class Group(models.Model):
    name = models.CharField(max_length=150)
    degree = models.ForeignKey(Degree, related_name='groups', on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.name}'