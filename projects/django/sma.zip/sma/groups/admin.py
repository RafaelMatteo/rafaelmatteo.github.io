# groups/admin.py

from django.contrib import admin
from groups.models import Group

# Register your models here.
admin.site.register(Group)