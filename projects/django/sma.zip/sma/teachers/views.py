# teachers/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from teachers.forms import TeacherChangeForm, TeacherCreationForm
from teachers.models import Teacher


@login_required
def teacherList(request):
    teachers = Teacher.objects.order_by('id_number')
    total_teachers = Teacher.objects.count()
    return render(request, 'teachers/teacherList.html', {'teachers': teachers, 'total_teachers': total_teachers})
    

@login_required
def teacherDetails(request, id):
    teacher = get_object_or_404(Teacher, pk=id)
    return render(request, 'teachers/teacherDetails.html', {'teacher': teacher})


@login_required
def teacherCreation(request):
    if request.method == 'POST':
       form = TeacherCreationForm(request.POST)
       if form.is_valid():
            form.save()
            return redirect('teacherList')
    else:
        form = TeacherCreationForm()

    return render(request, 'teachers/teacherCreation.html', {'form': form})
    

@login_required
def teacherUpdate(request, id):
    teacher = get_object_or_404(Teacher, pk=id)
    if request.method == 'POST':
        form = TeacherChangeForm(request.POST, instance=teacher)
        if form.is_valid():
            form.save()
            return redirect('teacherList')
    else:
        form = TeacherChangeForm(instance=teacher)

    return render(request, 'teachers/teacherUpdate.html', {'form': form})


@login_required
def teacherDelete(request, id):
    pass
    teacher = get_object_or_404(Teacher, pk=id)
    if teacher:
        teacher.delete()
    return redirect('teacherList')