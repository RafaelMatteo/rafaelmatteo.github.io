# teachers/forms.py

from django.forms import EmailInput, ModelForm
from teachers.models import Teacher


class TeacherCreationForm(ModelForm):

    class Meta:
        model = Teacher
        fields = '__all__'
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})
        }


class TeacherChangeForm(ModelForm):

    class Meta:
        model = Teacher
        fields = '__all__'
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})
        }