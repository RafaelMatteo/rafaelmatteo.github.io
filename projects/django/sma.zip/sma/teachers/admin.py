# teachers/admin.py

from django.contrib import admin
from teachers.models import Teacher

# Register your models here.
admin.site.register(Teacher)