# teachers/models.py

from django.db import models
from common.models import Person

# Create your models here.
class Teacher(Person):
    specialty = models.CharField(max_length=150)
    admission_date = models.DateField()
    
    def __str__(self):
        return f'{self.name} {self.last_name}, Specialty: {self.specialty}'
    