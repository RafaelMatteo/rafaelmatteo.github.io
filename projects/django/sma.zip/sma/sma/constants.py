# sma/config.py

# Months of the school year
SCHOOL_YEAR = ["March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

# Qualifications Range
MONTH_GRADES = {
    'A': 'Excellent',
    'B': 'Good',
    'C': 'Enough',
    'D': 'Insufficient',
    'F': 'Failed',
}


