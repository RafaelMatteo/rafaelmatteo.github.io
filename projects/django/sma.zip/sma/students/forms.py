# accounts/forms.py

from django import forms
from django.forms import EmailInput, ModelForm
from students.models import Student


class StudentCreationForm(ModelForm):
    
    class Meta:
        model = Student
        
        fields = (
            'id_number',
            'name',
            'last_name',
            'birth_date',
            'sex',
            'nationality',
            'address',
            'city',
            'phone',
            'email',
            'degree',
            'group',
            'admission_date',
                  )
        # '__all__'
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})
        }
        
        
class StudentChangeForm(ModelForm):

    class Meta:
        model = Student
        fields = '__all__'
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})
        }