# students/urls.py

from django.urls import include, path
from students.views import studentCreation, studentDelete, studentDetails, studentList, studentUpdate


urlpatterns = [
    path('studentList/', studentList, name='studentList'),
    path('studentCreation/', studentCreation, name='studentCreation'),
    path('studentDetails/<int:id>', studentDetails, name='studentDetails'),
    path('studentUpdate/<int:id>', studentUpdate, name='studentUpdate'),
    path('studentDelete/<int:id>', studentDelete, name='studentDelete'),
]