# references/models.py

from django.db import models
from common.models import Person

# Create your models here.
class Reference(Person):
    relationship = models.CharField(max_length=150)
    occupation = models.CharField(max_length=150, blank=True)
    
    def __str__(self):
        return f'{self.name} {self.last_name}, Phone: {self.phone} - {self.relationship}'
    