# references/urls.py

from django.urls import path
from references.views import referenceCreation, referenceDelete, referenceDetails, referenceList, referenceUpdate


urlpatterns = [
    path('referenceList/', referenceList, name='referenceList'),
    path('referenceCreation/', referenceCreation, name='referenceCreation'),
    path('referenceDetails/<int:id>', referenceDetails, name='referenceDetails'),
    path('referenceUpdate/<int:id>', referenceUpdate, name='referenceUpdate'),
    path('referenceDelete/<int:id>', referenceDelete, name='referenceDelete'),
]