# references/views.py

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from references.forms import Reference, ReferenceChangeForm, ReferenceCreationForm


# Create your views here.

@login_required
def referenceList(request):
    references = Reference.objects.order_by('id_number')
    total_references = Reference.objects.count()
    return render(request, 'references/referenceList.html', {'references': references, 'total_references': total_references})
    

@login_required
def referenceDetails(request, id):
    reference = get_object_or_404(Reference, pk=id)
    return render(request, 'references/referenceDetails.html', {'reference': reference})


@login_required
def referenceCreation(request):
    if request.method == 'POST':
        form = ReferenceCreationForm(request.POST)
        if form.is_valid():   
            form.save()
            return redirect('studentCreation')
    else:
        form = ReferenceCreationForm()

    return render(request, 'references/referenceCreation.html', {'form': form})
    

@login_required
def referenceUpdate(request, id):
    reference = get_object_or_404(Reference, pk=id)
    if request.method == 'POST':
        form = ReferenceChangeForm(request.POST, instance=reference)
        if form.is_valid():
            form.save()
            return redirect('referenceList')
    else:
        form = ReferenceChangeForm(instance=reference)

    return render(request, 'references/referenceUpdate.html', {'form': form})


@login_required
def referenceDelete(request, id):
    reference = get_object_or_404(Reference, pk=id)
    if reference:
        reference.delete()
    return redirect('referenceList')
