# references/forms.py

from django.forms import EmailInput, ModelForm
from references.models import Reference


class ReferenceCreationForm(ModelForm):

    class Meta:
        model = Reference
        fields = '__all__'
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})
        }

class ReferenceChangeForm(ModelForm):

    class Meta:
        model = Reference
        fields = '__all__'
        widgets = {
            'email': EmailInput(attrs={'type': 'email'})
        }