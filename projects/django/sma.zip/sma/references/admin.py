# references/admin.py

from django.contrib import admin
from references.models import Reference


# Register your models here.
admin.site.register(Reference)