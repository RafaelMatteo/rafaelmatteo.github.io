# ratings/views.py

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from django.shortcuts import render
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required

from sma.constants import SCHOOL_YEAR, MONTH_GRADES
from groups.models import Group
from grades.models import MonthlyGrade
from subjects.models import Subject
from students.models import Student


@login_required
def monthlyGradeAssign(request):
    subjects = Subject.objects.order_by('name')
    groups = Group.objects.order_by('name')
    students = Student.objects.order_by('id_number')
    month = SCHOOL_YEAR
    month_grades = MONTH_GRADES

    return render(request, 'grades/monthlyGradeAssign.html', {'groups': groups,
                                                               'students': students,
                                                               'subjects': subjects,
                                                               'months': month,
                                                               'month_grades': month_grades,
                                                                })
    
    
@login_required
def monthlyGradeUpdate(request):
    subjects = Subject.objects.order_by('name')
    groups = Group.objects.order_by('name')
    students = Student.objects.order_by('id_number')
    monthlyGrades = MonthlyGrade.objects.order_by('group')
    month = SCHOOL_YEAR
    month_grades = MONTH_GRADES

    return render(request, 'grades/monthlyGradeUpdate.html', {'groups': groups,
                                                              'students': students,
                                                              'subjects': subjects,
                                                              'months': month,
                                                              'month_grades': month_grades,
                                                              'monthlyGrades': monthlyGrades,
                                                                })


@login_required
def monthlyGradeList(request):
    subjects = Subject.objects.order_by('name')
    groups = Group.objects.order_by('name')
    students = Student.objects.order_by('id_number')
    monthlyGrades = MonthlyGrade.objects.order_by('group')
    month = SCHOOL_YEAR
    month_grades = MONTH_GRADES

    return render(request, 'grades/monthlyGradeList.html', {'groups': groups,
                                                            'students': students,
                                                            'subjects': subjects,
                                                            'months': month,
                                                            'month_grades': month_grades,
                                                            'monthlyGrades': monthlyGrades,
                                                                })
    

@login_required
def studentsAndGrades(request):
    group_id = request.GET.get('group')
    month = request.GET.get('month')
    subject_id = request.GET.get('subject')

    group = get_object_or_404(Group, id=group_id)
    subject = get_object_or_404(Subject, id=subject_id)
    grades = MonthlyGrade.objects.filter(group=group, month=month, subject=subject)

    data = []
    for grade in grades:
        data.append({
            'student': {
                'id': grade.student.id,
                'id_number': grade.student.id_number,
                'name': grade.student.name,
                'last_name': grade.student.last_name,
            },
            'group': grade.group.name,
            'month': grade.month,
            'subject': grade.subject.name,
            'month_grade': grade.month_grade,
            'month_grade_display': MONTH_GRADES.get(grade.month_grade, 'Unknown'),
        })

    return JsonResponse(data, safe=False)


@login_required
def subjectsAndGrades(request):
    group_id = request.GET.get('group')
    month = request.GET.get('month')
    student_id = request.GET.get('student')

    group = get_object_or_404(Group, id=group_id)
    student = get_object_or_404(Student, id=student_id)
    grades = MonthlyGrade.objects.filter(group=group, month=month, student=student)

    data = []
    for grade in grades:
        data.append({
            'subject': {
                'id': grade.subject.id,
                'name': grade.subject.name,
            },
            'student': grade.student.id_number,
            'group': grade.group.name,
            'month': grade.month,
            'month_grade': grade.month_grade,
            'month_grade_display': MONTH_GRADES.get(grade.month_grade, 'Unknown'),
        })

    return JsonResponse(data, safe=False)


@login_required
def monthlyGradeDelete(request, id):
    monthlyGrade = get_object_or_404(MonthlyGrade, pk=id)
    if monthlyGrade:
        monthlyGrade.delete()
    return redirect('monthlyGradeUpdate')
    
    
@login_required
@csrf_exempt
def saveMonthlyGrade(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            group = get_object_or_404(Group, id=data.get('group'))
            student = get_object_or_404(Student, id=data.get('student_id'))
            subject = get_object_or_404(Subject, id=data.get('subject'))
            month = data.get('month')
            grade = data.get('grade')

            # The student's grade is saved here
            student_grade, create = MonthlyGrade.objects.update_or_create(
                month = month,
                month_grade = grade,
                group = group,
                student = student,
                subject = subject,
            )
            
            return JsonResponse({'message': 'Grade saved successfully'}, status=200)
        except Exception as e:
            return JsonResponse({'message': 'Failed to save grade', 'error': str(e)}, status=400)
    else:
        return JsonResponse({'message': 'Invalid request method'}, status=405)
    

@login_required
@csrf_exempt
def updateMonthlyGrade(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)

            group = get_object_or_404(Group, id=data.get('group'))
            student = get_object_or_404(Student, id=data.get('student_id'))
            subject = get_object_or_404(Subject, id=data.get('subject'))
            month = data.get('month')
            month_grade = data.get('grade')

            # Update or create the student's grade
            student_grade, created = MonthlyGrade.objects.update_or_create(
                group = group,
                student = student,
                subject = subject,
                month = month,
                defaults = {'month_grade': month_grade}
            )
            
            return JsonResponse({'message': 'Grade updated successfully'}, status=200)
        except Exception as e:
            return JsonResponse({'message': 'Failed to update grade', 'error': str(e)}, status=400)
    else:
        return JsonResponse({'message': 'Invalid request method'}, status=405)


@login_required
def subjectsByGroup(request):
    group_id = request.GET.get('group')
    if group_id:
        subjects = Subject.objects.filter(group_id=group_id).values('id', 'name')
        return JsonResponse(list(subjects), safe=False)
    else:
        return JsonResponse([], safe=False)


def studentsByGroup(request):
    group_id = request.GET.get('group')
    if group_id:
        students = Student.objects.filter(group_id=group_id).values('id', 'id_number', 'name', 'last_name').order_by('id_number')
        return JsonResponse(list(students), safe=False)
    else:
        return JsonResponse([], safe=False)